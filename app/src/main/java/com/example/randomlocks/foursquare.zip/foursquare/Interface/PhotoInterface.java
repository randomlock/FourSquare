package com.example.randomlocks.foursquare.Interface;

import java.util.ArrayList;

/**
 * Created by randomlocks on 11/11/2015.
 */
public interface PhotoInterface {
    void processFinish(ArrayList<String> output,String title,String phone,String rating,String address,String tips,double distance,String venueid);
}
