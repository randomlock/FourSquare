package com.example.randomlocks.foursquare;

import java.util.ArrayList;

/**
 * Created by randomlocks on 11/11/2015.
 */
public class PhotoList {

    private ArrayList<String> photolist;

    public PhotoList(ArrayList<String> photolist) {


        this.photolist = photolist;
    }


    public ArrayList<String> getPhotolist() {
        return photolist;
    }
}
